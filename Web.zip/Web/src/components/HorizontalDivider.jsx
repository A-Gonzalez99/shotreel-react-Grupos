import '../App.css';

function HorizontalDivider() {

    return (
        <div className="horizontalDivider"/>
    )
}
    
export default HorizontalDivider