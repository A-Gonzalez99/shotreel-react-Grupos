export function ProyectName({nam}){
    return(
        <>
        <h1 className="h1Proyect">Name</h1>
        <p className="pBlack">{nam}</p>
        </>
    );

}