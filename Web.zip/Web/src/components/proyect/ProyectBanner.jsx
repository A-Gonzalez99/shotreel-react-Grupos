export function ProyectBanner({ima}){
    return(
        <>
        <div className='bannerProyect'>
            <img src={ima}></img>
        </div>
        </>
    );

}