export function ProyectDescription({des}){
    return(
        <>        
            <h1 className="h1Proyect">Description</h1>
            <p className="pBlack">{des}</p>
        </>
    );

}