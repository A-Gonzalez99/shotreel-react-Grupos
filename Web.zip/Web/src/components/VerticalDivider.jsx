import '../App.css';

function VerticalDivider() {

    return (
        <div className="verticalDivider"/>
    )
}
    
export default VerticalDivider